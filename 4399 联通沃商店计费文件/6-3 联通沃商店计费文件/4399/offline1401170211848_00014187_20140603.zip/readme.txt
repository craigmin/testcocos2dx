压缩包中分部分:
1.文件夹放入工程assets目录下
2.JAR包替换原来的同名JAR包
3.自己打包sdk初始化type为1
  联通打包sdk初始化type为0